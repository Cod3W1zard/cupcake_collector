import sys
import asyncio

async def main():
    import asyncio
    import pygame
    import random

    pygame.init()

    WIDTH = 600
    HEIGHT = 400
    WORLD_WIDTH = 1200

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Cupcake Collector")
    clock = pygame.time.Clock()
        
    running = True

    score = 0

    player_image = pygame.image.load("assets/player.png").convert_alpha()
    player_image = pygame.transform.scale(player_image, (50, 50))

    cupcake_image = pygame.image.load("assets/cupcake.png").convert_alpha()
    cupcake_image = pygame.transform.scale(cupcake_image, (30, 30))

    font = pygame.font.Font(None, 50)
    text_surface = font.render("Score: " + str(score), True, (255, 255, 255))
    text_rect = text_surface.get_rect()
    text_rect.center = (100, 50)

    player_x = WORLD_WIDTH / 2
    player_y = 300
    player_dy = 0
    gravity = 0.5
    jump_speed = -10
    on_ground = True
    double_jump_available = True


    class TaggedRect(pygame.Rect):
        def __init__(self, x, y, width, height, static = False ,movement_current = 0, movement_max = 50, movement_speed = 1):
            super().__init__(x, y, width, height)
            self.static = static
            self.movement_current = movement_current
            self.movement_max = movement_max
            self.movement_speed = movement_speed
            self.y += movement_current

    platforms = [
        TaggedRect(-1, 0, 1, 350, static=True),
        TaggedRect(WORLD_WIDTH, 0, 1, 350, static=True),
        TaggedRect(0, 350, WORLD_WIDTH, 50, static=True),
        TaggedRect(400, 230, 150, 20, static=False, movement_current=50),
        TaggedRect(650, 180, 150, 20, static=False,movement_current=-50, movement_speed = -1),
    ]

    cupcakes = []

    for cupcake in range(20):
        while True:
            cupcake_rect = pygame.Rect(random.randint(50, WORLD_WIDTH - 50), random.randint(50, HEIGHT - 50), 30, 30)
            if not any(cupcake_rect.colliderect(platform) for platform in platforms):
                cupcakes.append(cupcake_rect)
                break

    player_rect = pygame.Rect(player_x, player_y, 50, 50)

    camera_x = player_rect.centerx - WIDTH / 2


    def clamp_camera():
        nonlocal camera_x
        camera_x = max(0, min(camera_x, WORLD_WIDTH - WIDTH))


    def moveCamera(dist):
        nonlocal camera_x
        player_rect.x += dist
        player_rect.x = max(0, min(player_rect.x, WORLD_WIDTH - player_rect.width))
        camera_x = player_rect.centerx - WIDTH / 2
        clamp_camera()

    while running:
        # EVENT
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    if on_ground:
                        player_dy = jump_speed
                        on_ground = False
                    elif double_jump_available:
                        player_dy = jump_speed
                        double_jump_available = False

        keys = pygame.key.get_pressed()

        for platform in platforms:
            if platform.static == False:
                if platform.movement_current == platform.movement_max or platform.movement_current == -platform.movement_max:
                    platform.movement_speed *= -1
                platform.y += platform.movement_speed
                platform.movement_current += platform.movement_speed
                if platform.movement_current > platform.movement_max:
                    platform.movement_current = platform.movement_max
                if platform.movement_current < -platform.movement_max:
                    platform.movement_current = -platform.movement_max

        previous_x = player_rect.x

        if keys[pygame.K_LEFT]:
            player_rect.x -= 5
        if keys[pygame.K_RIGHT]:
            player_rect.x += 5

        for platform in platforms:
            if not player_rect.colliderect(platform):
                continue

            if previous_x + player_rect.width <= platform.x + 1 and player_rect.right > platform.left:
                player_rect.right = platform.left
            elif previous_x >= platform.right - 1 and player_rect.left < platform.right:
                player_rect.left = platform.right

        player_rect.x = max(0, min(player_rect.x, WORLD_WIDTH - player_rect.width))

        previous_y = player_rect.y
        player_dy += gravity
        player_rect.y += player_dy

        for platform in platforms:
            if not player_rect.colliderect(platform):
                continue

            previous_bottom = previous_y + player_rect.height
            previous_top = previous_y

            if player_dy > 0 and previous_bottom <= platform.top + 6:
                player_rect.bottom = platform.top
                on_ground = True
                double_jump_available = True
                player_dy = 0
            elif player_dy < 0 and previous_top >= platform.bottom - 6:
                player_rect.top = platform.bottom
                player_dy = 0

        camera_x = player_rect.centerx - WIDTH / 2
        clamp_camera()
                    
        for cupcake in cupcakes[:]:
            if player_rect.colliderect(cupcake):
                cupcakes.remove(cupcake)
                score += 1
                text_surface = font.render("Score: " + str(score), True, (255, 255, 255))
                text_rect = text_surface.get_rect()
                text_rect.center = (100, 50)

        screen.fill((20, 24, 40))
        screen.blit(player_image, (player_rect.x - camera_x, player_rect.y))
        for platform in platforms:
                pygame.draw.rect(
                    screen,
                    (180, 100, 100),
                    (platform.x - camera_x, platform.y, platform.width, platform.height)
                )
                
        for cupcake in cupcakes:
            screen.blit(
                cupcake_image,
                (cupcake.x-camera_x, cupcake.y)
            )

        screen.blit(text_surface, text_rect)

        pygame.display.flip()


        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())

sys.exit()
